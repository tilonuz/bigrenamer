class Translation(object):
    START_TEXT = """Salom xush kelibsiz! Men xajmi 1.5GB gacha bolgan fayllarni juda tezkorlik bilan qayta nomlab beraman. Bu hammasi emas,men url manzildagi va YouTubedagi videolarni osonlik bilan sizga shu yerda yuboraman.Zip fayllarniham arxivdan chiqarib ichidagi barcha malumotlarni shu yerda jonatishim mumkin."""
    RENAME_403_ERR = "Kechirasiz,ushbu faylni qayta nomlab bolmadi.Birozdan song qayta urinib koring."
    ABS_TEXT = "Iltimos, xudbin bo'lmang."
    UPGRADE_TEXT = "USHBU BOT @OYATlLLO TOMONIDAN ISHLAB CHIQILDI."
    FORMAT_SELECTION = "Kerakli formatni tanlang: <a href='{}'> fayl hajmi taxminiy bo'lishi mumkin </a> \nAgar siz o'zingizning shaxsiy thumbnailingizni o'rnatmoqchi bo'lsangiz, quyidagi tugmalarning birini bosgandan so'ng yoki oldin tezroq fotosuratni yuboring. \nAgar videoga qoyilayotgan thumbnailni ochirish uchun /deletethumbnail buyrugini yuborib ochirishingiz mumkin foydalanishingiz mumkin."
    SET_CUSTOM_USERNAME_PASSWORD = """Agar siz premium videolarni yuklab olishni xohlasangiz, quyidagi formatda taqdim eting:
URL | fayl nomi | foydalanuvchi nomi | parol"""
    NOYES_URL = "Robot URL manzili aniqlandi. Iltimos, https://shrtz.me/PtsVnf6 dan foydalaning va menga tezkor URL manzilini oling, shunda men Telegram-ga yuklay olaman, boshqa foydalanuvchilar uchun sekinlashtirmagan holda"
    UPLOAD_START = "Yuklanmoqda..."
    RCHD_BOT_API_LIMIT = "Hajmi ruxsat etilgan kattalikdan (50MB) kattaroq. Shunga qaramay, yuklashga urinmoqdamiz."
    RCHD_TG_API_LIMIT = "{} Soniya ichida yuklab olindi. \nFayl hajmi aniqlandi: {} \nKechirasiz ammo men Telegram API cheklovlari tufayli 1.5 Gb dan katta fayllarni yuklay olmayman."
    AFTER_SUCCESSFUL_UPLOAD_MSG = "Iltimos botni dostlaringiz bilan baham koring"
    AFTER_SUCCESSFUL_UPLOAD_MSG_WITH_TS = "{} vaqt ichida yuklab olindi.\nSizga {} sekunda yuborildi."
    NOT_AUTH_USER_TEXT = "Iltimos /upgrade burugini yuboring "
    NOT_AUTH_USER_TEXT_FILE_SIZE = "Aniqlangan fayl hajmi: {}. Bepul tarifdagi foydalanuvchilar faqat {} xajmgacha fayllarni yuklashlari mumkin. \nIltimos /upgrade burugi orqali obunangizni yangilang. \nAgar bu xato deb o'ylasangiz, <a href='https://telegram.dog/oyatlllo'> @OYATlLLO </a> bilan bog'laning."
    SAVED_CUSTOM_THUMB_NAIL = "Thumbnail muvaffaqiyatli sozlandi.Endi buni barcha yuklangan video / fayllar ustida korishingiz mumkin."
    DEL_ETED_CUSTOM_THUMB_NAIL = "✅Thumbnail muvoffaqiyatli ochirildi"
    FF_MPEG_DEL_ETED_CUSTOM_MEDIA = "✅ Media cleared succesfully."
    SAVED_RECVD_DOC_FILE = "Document Downloaded Successfully."
    CUSTOM_CAPTION_UL_FILE = " "
    NO_CUSTOM_THUMB_NAIL_FOUND = "No Custom ThumbNail found."
    NO_VOID_FORMAT_FOUND = "no-one gonna help you\n<b>YouTubeDL</b> said: {}"
    USER_ADDED_TO_DB = "User <a href='tg://user?id={}'>{}</a> added to {} till {}."
    CURENT_PLAN_DETAILS = """Current plan details
--------
Telegram ID: <code>{}</code>
Plan name: <a href='https://t.me/SpEcHlDe/599'>{}</a>
Expires on: {}"""
    HELP_USER = """There are multiple things I can do:
👉 <a href="https://t.me/SpEcHlDe/608">All Supported Video / File Formats, with custom file name and custom thumbnail support</a>
👉 <a href="https://t.me/SpEcHlDe/609">Upload as file from any HTTP link, with custom thumbnail support</a>
👉 <a href="https://telegram.dog/AnyDLBot">Convert To Streamable Video, any Telegram file</a>
👉 <a href="https://telegram.dog/AnyDLBot">Convert To Telegram Audio, the media sent as Telegram Documents</a>
👉 <a href="https://t.me/SpEcHlDe/610">ReName Telegram files, with custom thumbnail support</a>
👉 <a href="https://t.me/SpEcHlDe/625">Generate Custom Thumbnail by sending two photos in a Media Album</a>
👉 <a href="https://t.me/SpEcHlDe/653">Trim large videos</a>, and <a href="https://t.me/SpEcHlDe/652">Take Screenshots</a> of Telegram media files.
👉 <a href="https://t.me/SpEcHlDe/657">Extract compressed Telegram media</a>
👉 <a href="https://t.me/SpEcHlDe/660">Get a Telegram sticker as a Telegram downloadable media</a>
--------
Send /me to know current plan details"""
    REPLY_TO_DOC_GET_LINK = "Reply to a Telegram media to get High Speed Direct Download Link"
    REPLY_TO_DOC_FOR_C2V = "Reply to a Telegram media to convert"
    REPLY_TO_DOC_FOR_SCSS = "Reply to a Telegram media to get screenshots"
    REPLY_TO_DOC_FOR_RENAME_FILE = "Reply to a Telegram media to /rename with custom thumbnail support"
    AFTER_GET_DL_LINK = "Direct Link <a href='{}'>Generated</a> valid for {} days.\n© @AnyDLBot"
    FF_MPEG_RO_BOT_RE_SURRECT_ED = """Syntax: /trim HH:MM:SS [HH:MM:SS]"""
    FF_MPEG_RO_BOT_STEP_TWO_TO_ONE = "First send /downloadmedia to any media so that it can be downloaded to my local. \nSend /storageinfo to know the media, that is currently downloaded."
    FF_MPEG_RO_BOT_STOR_AGE_INFO = "Video Duration: {}\nSend /clearffmpegmedia to delete this media, from my storage.\nSend /trim HH:MM:SS [HH:MM:SS] to cu[l]t a small photo / video, from the above media."
    FF_MPEG_RO_BOT_STOR_AGE_ALREADY_EXISTS = "A saved media already exists. Please send /storageinfo to know the current media details."
    USER_DELETED_FROM_DB = "User <a href='tg://user?id={}'>{}</a> deleted from DataBase."
    REPLY_TO_DOC_OR_LINK_FOR_RARX_SRT = "Reply to a Telegram media (MKV), to extract embedded streams"
    REPLY_TO_MEDIA_ALBUM_TO_GEN_THUMB = "Reply /generatecustomthumbnail to a media album, to generate custom thumbail"
    ERR_ONLY_TWO_MEDIA_IN_ALBUM = "Media Album should contain only two photos. Please re-send the media album, and then try again, or send only two photos in an album."
    INVALID_UPLOAD_BOT_URL_FORMAT = "URL format is incorrect. make sure your url starts with either http:// or https://. You can set custom file name using the format link | file_name.extension"
    ABUSIVE_USERS = "You are not allowed to use this bot. If you think this is a mistake, please check /me to remove this restriction."
    FF_MPEG_RO_BOT_AD_VER_TISE_MENT = "https://telegram.dog/FFMpegRoBot"
    EXTRACT_ZIP_INTRO_ONE = "Send a compressed file first, Then reply /unzip command to the file."
    EXTRACT_ZIP_INTRO_THREE = "Analyzing received file. ⚠️ This might take some time. Please be patient. "
    UNZIP_SUPPORTED_EXTENSIONS = ("zip", "rar")
    EXTRACT_ZIP_ERRS_OCCURED = "Sorry. Errors occurred while processing compressed file. Please check everything again twice, and if the issue persists, report this to <a href='https://telegram.dog/ThankTelegram'>@SpEcHlDe</a>"
    EXTRACT_ZIP_STEP_TWO = """Select file_name to upload from the below options.
You can use /rename command after receiving file to rename it with custom thumbnail support."""
    CANCEL_STR = "Process Cancelled"
    ZIP_UPLOADED_STR = "Uploaded {} files in {} seconds"
    FREE_USER_LIMIT_Q_SZE = """Cannot Process.
Free users only 1 request per 30 minutes.
/upgrade or Try 1800 seconds later."""
    SLOW_URL_DECED = "Gosh that seems to be a very slow URL. Since you were screwing my home, I am in no mood to download this file. Meanwhile, why don't you try this:==> https://shrtz.me/PtsVnf6 and get me a fast URL so that I can upload to Telegram, without me slowing down for other users."
